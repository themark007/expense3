const express = require('express');
const router = express.Router();
const passport = require('passport');
const controllers = require('../controllers/mainController');

// Authentication routes
router.get('/', controllers.renderHome);
router.get('/login', controllers.renderLogin);
router.post('/login', passport.authenticate('local', {
    successRedirect: '/dashboard',
    failureRedirect: '/login',
    failureFlash: true
}));
router.get('/register', controllers.renderRegister);
router.post('/register', controllers.registerUser);
router.get('/dashboard', controllers.ensureAuthenticated, controllers.renderDashboard);
router.get('/logout', controllers.logoutUser);

// Expense routes
router.post('/add-expense', controllers.ensureAuthenticated, controllers.addExpense);
router.get('/delete-expense/:id', controllers.ensureAuthenticated, controllers.deleteExpense);

module.exports = router;
