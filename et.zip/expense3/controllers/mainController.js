const bcrypt = require('bcrypt');
const db = require('../config/db');

exports.ensureAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) return next();
    res.redirect('/login');
};

exports.renderHome = (req, res) => {
    res.render('home', { user: req.user });
};

exports.renderLogin = (req, res) => {
    res.render('login', { message: req.flash('error') });
};

exports.renderRegister = (req, res) => {
    res.render('register');
};

exports.registerUser = async (req, res) => {
    const { name, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    db.query('INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
        [name, email, hashedPassword],
        (err) => {
            if (err) return res.send('Error creating user');
            res.redirect('/login');
        });
};

exports.logoutUser = (req, res) => {
    req.logout(err => {
        if (err) console.error(err);
        res.redirect('/login');
    });
};

exports.renderDashboard = (req, res) => {
    db.query('SELECT * FROM expenses WHERE user_id = ?', [req.user.id], (err, results) => {
        if (err) throw err;

        const income = results.filter(e => e.type === 'income').reduce((sum, e) => sum + e.amount, 0);
        const expense = results.filter(e => e.type === 'expense').reduce((sum, e) => sum + e.amount, 0);

        res.render('dashboard', {
            user: req.user,
            expenses: results,
            income,
            expense,
            balance: income - expense
        });
    });
};

exports.addExpense = (req, res) => {
    const { title, amount, category, type } = req.body;
    db.query(
        'INSERT INTO expenses (user_id, title, amount, category, type) VALUES (?, ?, ?, ?, ?)',
        [req.user.id, title, amount, category, type],
        (err) => {
            if (err) throw err;
            res.redirect('/dashboard');
        }
    );
};

exports.deleteExpense = (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM expenses WHERE id = ? AND user_id = ?', [id, req.user.id], (err) => {
        if (err) throw err;
        res.redirect('/dashboard');
    });
};
