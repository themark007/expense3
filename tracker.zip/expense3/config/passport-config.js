const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt');
const db = require('./db');

function initialize(passport) {
    const authenticateUser = (email, password, done) => {
        db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
            if (err) return done(err);
            if (results.length === 0) {
                return done(null, false, { message: 'No user with that email' });
            }

            const user = results[0];
            try {
                if (await bcrypt.compare(password, user.password)) {
                    return done(null, user);
                } else {
                    return done(null, false, { message: 'Password incorrect' });
                }
            } catch (e) {
                return done(e);
            }
        });
    };

    passport.use(new LocalStrategy({ usernameField: 'email' }, authenticateUser));
    passport.serializeUser((user, done) => done(null, user.id));
    passport.deserializeUser((id, done) => {
        db.query('SELECT * FROM users WHERE id = ?', [id], (err, results) => {
            if (err) return done(err);
            return done(null, results[0]);
        });
    });
}

module.exports = initialize;

